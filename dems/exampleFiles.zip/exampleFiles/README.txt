Contained in this zip folder is a collection of sample DEM files for user testing. 

misc: miscellaneous files from around the world
|_ Crater Lake, Oregon
|_ Mount Everest, Nepal
|_ Mount Kilimanjaro, Tanzania
|_ Matterhorn, Switzerland
|_ Mount Rainier, Washington
|_ Stormking, Washington

sparse: files with a proportion of data removed so that the user may explore the interpolation features
|_ Crater Lake with 0.1 removed
|_ Franconia Ridge with 0.1 removed
|_ Kilimanjaro with 0.05 removed
|_ Rainier with 0.01 removed
|_ Washington with 0.075 removed
|_ Washington with 0.1 removed

whites: DEM files from the White Mountains in New Hampshire
|_ Mount Chocorua
|_ Franconia Ridge
|_ Tuckermans Ravine on Washington
|_ Pemigewasset Loop
|_ Mount Washington

